<?php
session_start();
$user = $_SESSION['user'];
if ($user == "") {
    
?>
<script>
    document.location='../index.php';
</script>
<?php
}else {
    

include "boot.php";
?>

<body>
    <!-- ini navbar -->
<div class="body">
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <h2 class="text-info">
                    <i class="bi bi-person-circle"></i> <i>KASIR WARKOP</i>
                </h2>
                <form class="d-flex" role="search" method="GET" action="tampil.php" target="konten">
                    <input class="form-control me-2" type="search" name="nama_barang" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success text-info" type="submit">Search</button>
                </form>
            </div>
</div>
    <!-- tutup navbar -->

    <!-- ini halaman -->
    <div class="form-control">
        <div class="row">
            <div class="col-3 mt-5 ms-2 rounded rounded-circle">
                <div class="list-group shadow-lg ">
                    <a class="" href="input.php" target="konten">
                        <button type="button" class="list-group-item list-group-item-action" aria-current="true"><b><i class="bi bi-cart-plus"></i> Input</b></button></a>
                    <a href="kasir.php" target="konten">
                        <button type="button" class="list-group-item list-group-item-action"><b><i class="bi bi-pc-display-horizontal"></i> Kasir</b></button></a>
                    <a href="tampil.php" target="konten">
                        <button type="button" class="list-group-item list-group-item-action"><b><i class="bi bi-card-heading"></i> Data Menu</b></button></a>
                    <a href="laporan.php" target="konten">
                    <button type="button" class="list-group-item list-group-item-action"><b><i class="bi bi-journal"></i> Laporan</b></button></a>
                    <a href="rekap.php" target="konten">
                        <button type="button" class="list-group-item list-group-item-action"><b><i class="bi bi-printer"></i> Print Menu</b></button></a>
                <a href="logout.php">
                    <button type="button" class="list-group-item list-group-item-action" onclick="javascript:return confirm('Anda yakin ingin keluar ?');" ><b><i class="bi bi-box-arrow-left"></i> Logout</b></button></a>
                </div>
            </div>
            <div class="col mt-2">
                <iframe src="tampil.php" name="konten" frameborder="0" width="100%" height="800"></iframe>
            </div>
        </div>
    </div>
    <!-- tutup halaman -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
</body>

</html>
<?php
}
?>