<?php
    $konek=new mysqli ("localhost","root","","kasir_warkop");
    date_default_timezone_set('Asia/Jakarta');
?>