<?php
  include "koneksi.php";
  $kode=$_POST['id_barang'];
  $gambar=$_POST['gambar'];
  $nama=$_POST['nama_barang'];
  $harga=$_POST['harga_barang'];
  $ttl=$_POST['tgl_input'];

  if ($nama== "") {
  echo  "Maaf harus diisi!!!";
  }else {
    move_uploaded_file($file, "image/$nama");
  $simpan =$konek->query("insert into menu (id_barang,gambar,nama_barang,harga_barang,tgl_input)values ('$kode','$gambar','$nama','$harga','$ttl')");
}
?>
<script>
    document.location.href ='input.php';
</script>


