<button class="btn" onclick="printDiv('div1')">
    <i class="bi bi-printer-fill fs-1"></i>
</button>

<div id="div1">

    <!-- tampil -->
    <?php
include "boot.php";
include "session.php";
include "koneksi.php";

$searchterm = isset($_GET['nama_barang']) ? $_GET['nama_barang'] : '';
$tampil = "SELECT * FROM menu WHERE nama_barang LIKE '%$searchterm%'";
$result = $konek->query($tampil);

function format_ribuan($nilai) {
    return number_format($nilai, 0, ',', '.');
}

?>

<div class="container">
    <div class="row">
        <div class="col-md-7">
            <h3>Data Menu</h3>
        </div>
        </form>
</div>
</div>
<table class="table table-bordered">
    <thead class=" table-info">
        <tr>
            <th scope="col">No</th>
            <th scope="col">Kode</th>
            <th scope="col">Nama menu</th>
            <th scope="col">Harga</th>
            <th scope="col">Waktu</th>
           
        </tr>
    </thead>
    <tbody>
        <?php
        $no =0;
        while ($s = $result->fetch_assoc()) {
            $no++;
        ?>
            <tr>
                <th scope="row"><?= $no; ?></th>
                <td><?= $s['id_barang'] ?></td>
                <td><?= $s['nama_barang'] ?></td>
                <td><?= format_ribuan($s['harga_barang']) ?></td>
                <td><?= $s['tgl_input'] ?></td>
            </tr>
        <?php
        }
        ?>
    </tbody>

</table>
</div>

<!-- tutup tampil -->
<script>
    function printDiv(el) {
        var c = document.body.innerHTML;
        var d = document.getElementById(el).innerHTML;

        document.body.innerHTML = d;
        window.print();
        document.body.innerHTML = c;
    }
</script>