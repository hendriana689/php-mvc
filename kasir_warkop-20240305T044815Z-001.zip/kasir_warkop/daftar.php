<?php
include "app/boot.php";
include "app/koneksi.php";
$namawarkop="WARKOP HENDRI"
?>
<head>

<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
</head>

<!-- barang -->
<div class="row">
<div class="container" style="background-image: url('images/bg11.jpg'); height:600px;">
<div class="col-md-9 mb-1 container me-1">
    <div class="col-md-6 mb-3">
        <div class="card mt-5 ">
            <div class="card-header ">
                    <div class="card-title text-dark"><i class="fa fa-shopping-cart"></i> <b>Tambah Akun Kasir</b></div>
                </div>
                <div class="card-body">
                    <form method="POST" target="" class="">
                        <div class="form-row">
                        </div>
                            <div class="form-group col-md-6">
                                <label><b>Nama WARKOP</b></label>
                                <input type="text" name="nama_warkop" class="form-control" value="<?php echo $namawarkop; ?>" readonly>
                            </div>
                            <div class="form-group col-md-6">
                                <label><b>Nama User</b></label>
                                <input type="text" name="user" class="form-control" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label><b>Password</b></label>
                                <input type="text" name="pass" class="form-control" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label><b>Alamat</b></label>
                                <input type="text" name="alamat" class="form-control" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label><b>No.Telpon</b></label>
                                <input type="number" name="telp" class="form-control" required>
                            </div>
                        <div class="container-login100-form-btn m-t-32">
                            <button name="simpan" value="simpan" class="login100-form-btn" type="submit">
                                <i class="fa fa-plus mr-2"></i>Tambah
                            </button>
                    <div class="container-login100-form-btn m-t-32">
                        <button class="login100-form-btn" type="submit" name="">
                        <a href="index.php">
                        <label class="text-light">Kembali</label>
                        </a>
                        </button>
                    </div>
                        </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
 <!-- end barang -->
 <?php
 if (isset($_POST['simpan'])) {
        $nama =$_POST['nama_warkop'] ;
        $namauser=$_POST['user'];
        $pass =$_POST['pass'] ;
        $alamat =$_POST['alamat'] ;
        $notlp =$_POST['telp'] ;


        $simpan = $konek->query("insert into login (nama_warkop, user, pass, alamat, telp) 
        VALUES ('$nama', '$namauser', '$pass', '$alamat', '$notlp')")
        or die(mysqli_error($konek));

        if ($simpan) {
            echo "<script>
                alert('Data berhasil ditambahkan');
                document.location.href = 'index.php';
            </script>";
        } else {
            echo "<script>
                alert('Gagal menambahkan data!!');
            </script>";
        }

 }

?>
